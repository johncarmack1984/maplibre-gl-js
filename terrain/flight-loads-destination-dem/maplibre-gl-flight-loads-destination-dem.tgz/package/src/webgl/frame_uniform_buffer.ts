import {UBO_BINDINGS, UniformBuffer, std140Layout} from './uniform_buffer.ts';

import type {Context} from './context.ts';
import type {FrameRenderData} from '../render/frame_render_context.ts';
import type {IReadonlyTransform} from '../geo/transform_interface.ts';

const layout = std140Layout([
    {name: 'u_units_to_pixels', type: 'vec2'},
    {name: 'u_world_size', type: 'vec2'},
    {name: 'u_camera_to_center_distance', type: 'float'},
    {name: 'u_symbol_fade_change', type: 'float'},
    {name: 'u_aspect_ratio', type: 'float'},
    {name: 'u_device_pixel_ratio', type: 'float'},
    {name: 'u_viewport_size', type: 'vec2'},
    {name: 'u_pixel_extrude_scale', type: 'vec2'},
    {name: 'u_pitch', type: 'float'},
]);
const offsets = layout.offsets;

/**
 * @internal
 * The buffer behind the `FrameUBO` block in the shader preludes. `Painter.render` fills it at the start of a frame,
 * and the terrain pass rewrites `u_world_size` around the renders into its textures.
 */
export function createFrameUniformBuffer(context: Context): UniformBuffer {
    return new UniformBuffer(context, UBO_BINDINGS.FrameUBO, layout);
}

export function updateFrameUniformBuffer(buffer: UniformBuffer, transform: IReadonlyTransform, data: FrameRenderData): void {
    const f32 = buffer.pending;
    const gl = buffer.context.gl;
    f32[offsets.u_units_to_pixels] = 1 / transform.pixelsToGLUnits[0];
    f32[offsets.u_units_to_pixels + 1] = 1 / transform.pixelsToGLUnits[1];
    f32[offsets.u_world_size] = gl.drawingBufferWidth;
    f32[offsets.u_world_size + 1] = gl.drawingBufferHeight;
    f32[offsets.u_camera_to_center_distance] = transform.cameraToCenterDistance;
    f32[offsets.u_symbol_fade_change] = data.fadeDuration ? data.symbolFadeChange : 1;
    f32[offsets.u_aspect_ratio] = transform.width / transform.height;
    f32[offsets.u_device_pixel_ratio] = data.pixelRatio;
    f32[offsets.u_viewport_size] = transform.width;
    f32[offsets.u_viewport_size + 1] = transform.height;
    f32[offsets.u_pixel_extrude_scale] = 1 / transform.width;
    f32[offsets.u_pixel_extrude_scale + 1] = 1 / transform.height;
    f32[offsets.u_pitch] = transform.pitch / 360 * 2 * Math.PI;
    buffer.upload();
}

/**
 * @internal
 * Sets `u_world_size` to the size of the render target about to be drawn into. It is the canvas size,
 * except while layers are drawn into a terrain texture; the fill outline shaders compare it with `gl_FragCoord`.
 */
export function setFrameUniformWorldSize(buffer: UniformBuffer, width: number, height: number): void {
    const f32 = buffer.pending;
    f32[offsets.u_world_size] = width;
    f32[offsets.u_world_size + 1] = height;
    buffer.upload();
}
