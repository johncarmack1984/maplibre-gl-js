import {type PreparedShader, shaders} from '../shaders/shaders.ts';
import {VertexArrayObject} from './vertex_array_object.ts';
import {terrainPreludeUniforms, type TerrainPreludeUniformsType} from './program/terrain_program.ts';
import {applyUBOBindings} from './uniform_buffer.ts';
import {bindProjectionUniformBuffer} from './projection_uniform_buffer.ts';
import {updateTerrainUniformBuffer} from './terrain_uniform_buffer.ts';

import type {ProgramConfiguration} from '../data/program_configuration.ts';
import type {Context} from './context.ts';
import type {SegmentVector} from '../data/segment.ts';
import type {VertexBuffer} from './vertex_buffer.ts';
import type {IndexBuffer} from './index_buffer.ts';
import type {DepthMode} from './depth_mode.ts';
import type {StencilMode} from './stencil_mode.ts';
import type {ColorMode} from './color_mode.ts';
import type {CullFaceMode} from './cull_face_mode.ts';
import type {UniformBindings, UniformValues, UniformLocations} from './uniform_binding.ts';
import type {BinderUniform} from '../data/program_configuration.ts';
import type {TerrainData} from '../render/terrain.ts';
import type {ProjectionData} from '../geo/projection/projection_data.ts';

export type DrawMode = WebGLRenderingContextBase['LINES'] | WebGLRenderingContextBase['TRIANGLES'] | WebGL2RenderingContext['LINE_STRIP'];

function getTokenizedAttributesAndUniforms(array: string[]): string[] {
    const result = [];

    for (const entry of array) {
        if (entry === null) continue;
        const token = entry.split(' ');
        result.push(token.pop());
    }
    return result;
}

function getIntegerAttributeNames(gl: WebGL2RenderingContext, program: WebGLProgram): Set<string> {
    const integerTypes = new Set<number>([
        gl.INT, gl.INT_VEC2, gl.INT_VEC3, gl.INT_VEC4,
        gl.UNSIGNED_INT, gl.UNSIGNED_INT_VEC2, gl.UNSIGNED_INT_VEC3, gl.UNSIGNED_INT_VEC4
    ]);
    const names = new Set<string>();
    const numActiveAttributes = gl.getProgramParameter(program, gl.ACTIVE_ATTRIBUTES);
    for (let i = 0; i < numActiveAttributes; i++) {
        const attribute = gl.getActiveAttrib(program, i);
        if (attribute && integerTypes.has(attribute.type)) {
            names.add(attribute.name);
        }
    }
    return names;
}

export type ProgramAttribute = {
    location: number;
    isInteger: boolean;
};

/**
 * @internal
 * A webgl program to execute in the GPU space
 */
export class Program<Us extends UniformBindings> {
    program: WebGLProgram;
    attributes: {[_: string]: ProgramAttribute};
    numAttributes: number;
    fixedUniforms: Us;
    terrainUniforms: TerrainPreludeUniformsType;
    binderUniforms: BinderUniform[];
    failedToCreate: boolean;

    constructor(context: Context,
        source: PreparedShader,
        configuration: ProgramConfiguration,
        fixedUniforms: (b: Context, a: UniformLocations) => Us,
        showOverdrawInspector: boolean,
        useTerrain: boolean,
        projectionPrelude: PreparedShader,
        projectionDefine: string,
        extraDefines: string[] = []) {

        const gl = context.gl;
        this.program = gl.createProgram();

        const staticAttrInfo = getTokenizedAttributesAndUniforms(source.staticAttributes);
        const dynamicAttrInfo = configuration ? configuration.getBinderAttributes() : [];
        const allAttrInfo = staticAttrInfo.concat(dynamicAttrInfo);

        const preludeUniformsInfo = shaders.prelude.staticUniforms ? getTokenizedAttributesAndUniforms(shaders.prelude.staticUniforms) : [];
        const staticUniformsInfo = source.staticUniforms ? getTokenizedAttributesAndUniforms(source.staticUniforms) : [];
        const dynamicUniformsInfo = configuration ? configuration.getBinderUniforms() : [];
        // remove duplicate uniforms
        const uniformList = preludeUniformsInfo.concat(staticUniformsInfo).concat(dynamicUniformsInfo);
        const allUniformsInfo = [];
        for (const uniform of uniformList) {
            if (!allUniformsInfo.includes(uniform)) allUniformsInfo.push(uniform);
        }

        const defines = configuration ? configuration.defines() : [];
        defines.unshift('#version 300 es');
        if (showOverdrawInspector) {
            defines.push('#define OVERDRAW_INSPECTOR;');
        }
        if (useTerrain) {
            defines.push('#define TERRAIN3D;');
        }
        if (projectionDefine) {
            defines.push(projectionDefine);
        }
        if (extraDefines) {
            defines.push(...extraDefines);
        }

        const fragmentSource = defines.concat(shaders.prelude.fragmentSource, projectionPrelude.fragmentSource, source.fragmentSource).join('\n');
        const vertexSource = defines.concat(shaders.prelude.vertexSource, projectionPrelude.vertexSource, source.vertexSource).join('\n');

        const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
        if (gl.isContextLost()) {
            this.failedToCreate = true;
            return;
        }
        gl.shaderSource(fragmentShader, fragmentSource);
        gl.compileShader(fragmentShader);
        gl.attachShader(this.program, fragmentShader);

        const vertexShader = gl.createShader(gl.VERTEX_SHADER);
        if (gl.isContextLost()) {
            this.failedToCreate = true;
            return;
        }
        gl.shaderSource(vertexShader, vertexSource);
        gl.compileShader(vertexShader);
        gl.attachShader(this.program, vertexShader);

        this.attributes = {};
        const uniformLocations = {};

        this.numAttributes = allAttrInfo.length;

        // Link before reading any status so the driver can overlap both compiles; the shaders are
        // only asked how they compiled when the link failed, to name the one at fault.
        gl.linkProgram(this.program);

        if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) {
            // A dead GPU process answers every query with 0 until isContextLost() turns true, so a
            // failed link with zero attached shaders means the driver died, not the shaders (#8607).
            if (gl.isContextLost() || gl.getProgramParameter(this.program, gl.ATTACHED_SHADERS) === 0) {
                this.failedToCreate = true;
                return;
            }
            if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
                throw new Error(`Could not compile fragment shader: ${gl.getShaderInfoLog(fragmentShader)}`);
            }
            if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
                throw new Error(`Could not compile vertex shader: ${gl.getShaderInfoLog(vertexShader)}`);
            }
            throw new Error(`Program failed to link: ${gl.getProgramInfoLog(this.program)}`);
        }

        applyUBOBindings(gl, this.program);

        const integerAttributeNames = getIntegerAttributeNames(gl, this.program);
        for (const name of allAttrInfo) {
            if (!name) continue;
            const location = gl.getAttribLocation(this.program, name);
            if (location >= 0) {
                this.attributes[name] = {location, isInteger: integerAttributeNames.has(name)};
            }
        }

        gl.deleteShader(vertexShader);
        gl.deleteShader(fragmentShader);

        for (const uniform of allUniformsInfo) {
            if (uniform && !uniformLocations[uniform]) {
                const uniformLocation = gl.getUniformLocation(this.program, uniform);
                if (uniformLocation) {
                    uniformLocations[uniform] = uniformLocation;
                }
            }
        }

        this.fixedUniforms = fixedUniforms(context, uniformLocations);
        this.terrainUniforms = terrainPreludeUniforms(context, uniformLocations);
        this.binderUniforms = configuration ? configuration.getUniforms(context, uniformLocations) : [];
    }

    draw(context: Context,
        drawMode: DrawMode,
        depthMode: Readonly<DepthMode>,
        stencilMode: Readonly<StencilMode>,
        colorMode: Readonly<ColorMode>,
        cullFaceMode: Readonly<CullFaceMode>,
        uniformValues: UniformValues<Us>,
        terrain: TerrainData,
        projectionData: ProjectionData,
        layerID: string,
        layoutVertexBuffer: VertexBuffer,
        indexBuffer: IndexBuffer,
        segments: SegmentVector,
        currentProperties?: any,
        zoom?: number | null,
        configuration?: ProgramConfiguration | null,
        dynamicLayoutBuffer?: VertexBuffer | null,
        dynamicLayoutBuffer2?: VertexBuffer | null,
        dynamicLayoutBuffer3?: VertexBuffer | null): void {

        const gl = context.gl;

        if (this.failedToCreate) return;

        context.program.set(this.program);
        context.terrainUniformBuffer.bind();
        context.frameUniformBuffer.bind();
        context.setDepthMode(depthMode);
        context.setStencilMode(stencilMode);
        context.setColorMode(colorMode);
        context.setCullFace(cullFaceMode);

        // set variables used by the 3d functions defined in _prelude.vertex.glsl
        if (terrain) {
            context.activeTexture.set(gl.TEXTURE2);
            gl.bindTexture(gl.TEXTURE_2D, terrain.depthTexture);
            context.activeTexture.set(gl.TEXTURE3);
            gl.bindTexture(gl.TEXTURE_2D, terrain.texture);
            for (const name in this.terrainUniforms) {
                this.terrainUniforms[name].set(terrain[name]);
            }
            updateTerrainUniformBuffer(context.terrainUniformBuffer, terrain);
        }

        bindProjectionUniformBuffer(context, projectionData);

        if (uniformValues) {
            for (const name in this.fixedUniforms) {
                this.fixedUniforms[name].set(uniformValues[name]);
            }
        }

        if (configuration) {
            configuration.setUniforms(context, this.binderUniforms, currentProperties, {zoom});
        }

        let primitiveSize = 0;
        switch (drawMode) {
            case gl.LINES:
                primitiveSize = 2;
                break;
            case gl.TRIANGLES:
                primitiveSize = 3;
                break;
            case gl.LINE_STRIP:
                primitiveSize = 1;
                break;
        }

        for (const segment of segments.get()) {
            segment.vaos ||= {};
            segment.vaos[layerID] ||= new VertexArrayObject();
            segment.vaos[layerID].bind(
                context,
                this,
                layoutVertexBuffer,
                configuration ? configuration.getPaintVertexBuffers() : [],
                indexBuffer,
                segment.vertexOffset,
                dynamicLayoutBuffer,
                dynamicLayoutBuffer2,
                dynamicLayoutBuffer3
            );

            gl.drawElements(
                drawMode,
                segment.primitiveLength * primitiveSize,
                gl.UNSIGNED_SHORT,
                segment.primitiveOffset * primitiveSize * 2);
        }
    }
}
