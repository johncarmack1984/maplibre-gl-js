import {DepthMode} from '../depth_mode.ts';
import {StencilMode} from '../stencil_mode.ts';
import {CullFaceMode} from '../cull_face_mode.ts';
import {debugUniformValues} from '../program/debug_program.ts';
import {Color} from '@maplibre/maplibre-gl-style-spec';
import {ColorMode} from '../color_mode.ts';

import type {FrameRenderContext} from '../../render/frame_render_context.ts';
import type {Style} from '../../style/style.ts';
import type {Painter} from '../../render/painter.ts';
import type {TileManager} from '../../tile/tile_manager.ts';
import type {OverscaledTileID} from '../../tile/tile_id.ts';

const topColor = new Color(1, 0, 0, 1);
const btmColor = new Color(0, 1, 0, 1);
const leftColor = new Color(0, 0, 1, 1);
const rightColor = new Color(1, 0, 1, 1);
const centerColor = new Color(0, 1, 1, 1);

export function drawDebugPadding(frameRenderContext: FrameRenderContext): void {
    const padding = frameRenderContext.transform.padding;
    const lineWidth = 3;
    // Top
    drawHorizontalLine(frameRenderContext, frameRenderContext.transform.height - (padding.top || 0), lineWidth, topColor);
    // Bottom
    drawHorizontalLine(frameRenderContext, padding.bottom || 0, lineWidth, btmColor);
    // Left
    drawVerticalLine(frameRenderContext, padding.left || 0, lineWidth, leftColor);
    // Right
    drawVerticalLine(frameRenderContext, frameRenderContext.transform.width - (padding.right || 0), lineWidth, rightColor);
    // Center
    const center = frameRenderContext.transform.centerPoint;
    drawCrosshair(frameRenderContext, center.x, frameRenderContext.transform.height - center.y, centerColor);
}

function drawCrosshair(frameRenderContext: FrameRenderContext, x: number, y: number, color: Color) {
    const size = 20;
    const lineWidth = 2;
    //Vertical line
    drawDebugSSRect(frameRenderContext, x - lineWidth / 2, y - size / 2, lineWidth, size, color);
    //Horizontal line
    drawDebugSSRect(frameRenderContext, x - size / 2, y - lineWidth / 2, size, lineWidth, color);
}

function drawHorizontalLine(frameRenderContext: FrameRenderContext, y: number, lineWidth: number, color: Color) {
    drawDebugSSRect(frameRenderContext, 0, y  + lineWidth / 2, frameRenderContext.transform.width,  lineWidth, color);
}

function drawVerticalLine(frameRenderContext: FrameRenderContext, x: number, lineWidth: number, color: Color) {
    drawDebugSSRect(frameRenderContext, x - lineWidth / 2, 0, lineWidth,  frameRenderContext.transform.height, color);
}

function drawDebugSSRect(frameRenderContext: FrameRenderContext, x: number, y: number, width: number, height: number, color: Color) {
    const context = frameRenderContext.context;
    const gl = context.gl;
    const pixelRatio = frameRenderContext.data.pixelRatio;

    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(x * pixelRatio, y * pixelRatio, width * pixelRatio, height * pixelRatio);
    context.clear({color});
    gl.disable(gl.SCISSOR_TEST);
}

export function drawDebug(painter: Painter, tileManager: TileManager, coords: OverscaledTileID[], frameRenderContext: FrameRenderContext): void {
    for (const coord of coords) {
        drawDebugTile(painter, tileManager, coord, frameRenderContext);
    }
}

function drawDebugTile(painter: Painter, tileManager: TileManager, coord: OverscaledTileID, frameRenderContext: FrameRenderContext) {
    const context = frameRenderContext.context;
    const gl = context.gl;

    const program = frameRenderContext.useProgram('debug');

    const depthMode = DepthMode.disabled;
    const stencilMode = StencilMode.disabled;
    const colorMode = frameRenderContext.colorModeForRenderPass();
    const id = '$debug';
    const terrainData = frameRenderContext.getTerrainDataForTile(coord);

    context.activeTexture.set(gl.TEXTURE0);

    const tileRawData = tileManager.getTileByID(coord.key).latestRawTileData;
    const tileByteLength = (tileRawData?.byteLength) || 0;
    const tileSizeKb = Math.floor(tileByteLength / 1024);
    const tileSize = tileManager.getTile(coord).tileSize;
    const scaleRatio = (512 / Math.min(tileSize, 512) * (coord.overscaledZ / frameRenderContext.transform.zoom)) * 0.5;
    let tileIdText = coord.canonical.toString();
    if (coord.overscaledZ !== coord.canonical.z) {
        tileIdText += ` => ${coord.overscaledZ}`;
    }
    const tileLabel = `${tileIdText} ${tileSizeKb}kB`;
    drawTextToOverlay(painter, tileLabel);

    const projectionData = frameRenderContext.getProjectionDataForTile(coord);

    program.draw(context, gl.TRIANGLES, depthMode, stencilMode, ColorMode.alphaBlended, CullFaceMode.disabled,
        debugUniformValues(Color.transparent, scaleRatio), null, projectionData, id,
        painter.debugBuffer, painter.quadTriangleIndexBuffer, painter.debugSegments);
    program.draw(context, gl.LINE_STRIP, depthMode, stencilMode, colorMode, CullFaceMode.disabled,
        debugUniformValues(Color.red), terrainData, projectionData, id,
        painter.debugBuffer, painter.tileBorderIndexBuffer, painter.debugSegments);
}

function drawTextToOverlay(painter: Painter, text: string) {
    painter.initDebugOverlayCanvas();
    const canvas = painter.debugOverlayCanvas;
    const gl = painter.context.gl;
    const ctx2d = painter.debugOverlayCanvas.getContext('2d');
    ctx2d.clearRect(0, 0, canvas.width, canvas.height);

    ctx2d.shadowColor = 'white';
    ctx2d.shadowBlur = 2;
    ctx2d.lineWidth = 1.5;
    ctx2d.strokeStyle = 'white';
    ctx2d.textBaseline = 'top';
    ctx2d.font = `bold ${36}px Open Sans, sans-serif`;
    ctx2d.fillText(text, 5, 5);
    ctx2d.strokeText(text, 5, 5);

    painter.debugOverlayTexture.update(canvas);
    painter.debugOverlayTexture.bind(gl.LINEAR, gl.CLAMP_TO_EDGE);
}

export function selectDebugSource(style: Style, zoom: number): TileManager | null {
    // Use vector source with highest maxzoom
    // Else use source with highest maxzoom of any type
    let selectedSource: TileManager = null;
    const layers = Object.values(style._layers);
    const sources = layers.flatMap((layer) => {
        if (layer.source && !layer.isHidden(zoom)) {
            const tileManager = style.tileManagers[layer.source];
            return [tileManager];
        } else {
            return [];
        }
    });
    const vectorSources = sources.filter((source) => source.getSource().type === 'vector');
    const otherSources = sources.filter((source) => source.getSource().type !== 'vector');
    const considerSource = (source: TileManager) => {
        if (!selectedSource || (selectedSource.getSource().maxzoom < source.getSource().maxzoom)) {
            selectedSource = source;
        }
    };
    for (const source of vectorSources) {
        considerSource(source);
    }
    if (!selectedSource) {
        for (const source of otherSources) {
            considerSource(source);
        }
    }
    return selectedSource;
}
