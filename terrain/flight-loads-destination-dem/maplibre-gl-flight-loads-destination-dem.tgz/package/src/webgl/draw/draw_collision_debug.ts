import {DepthMode} from '../depth_mode.ts';
import {StencilMode} from '../stencil_mode.ts';
import {CullFaceMode} from '../cull_face_mode.ts';
import {QuadTriangleArray, CollisionCircleLayoutArray} from '../../data/array_types.g.ts';
import {collisionCircleLayout} from '../../data/bucket/symbol_attributes.ts';
import {SegmentVector} from '../../data/segment.ts';

import type {FrameRenderContext} from '../../render/frame_render_context.ts';
import type {VertexBuffer} from '../vertex_buffer.ts';
import type {IndexBuffer} from '../index_buffer.ts';
import type {SymbolBucket} from '../../data/bucket/symbol_bucket.ts';
import type {OverscaledTileID} from '../../tile/tile_id.ts';
import type {StyleLayer} from '../../style/style_layer.ts';
import type {TileManager} from '../../tile/tile_manager.ts';

type TileBatch = {
    circleArray: number[];
    circleOffset: number;
    coord: OverscaledTileID;
};

let quadTriangles: QuadTriangleArray;

export function drawCollisionDebug(tileManager: TileManager, layer: StyleLayer, coords: OverscaledTileID[], isText: boolean, frameRenderContext: FrameRenderContext): void {
    const context = frameRenderContext.context;
    const gl = context.gl;
    const program = frameRenderContext.useProgram('collisionBox');
    const tileBatches: TileBatch[] = [];
    let circleCount = 0;
    let circleOffset = 0;

    for (const coord of coords) {
        const tile = tileManager.getTile(coord);
        const bucket: SymbolBucket = (tile.getBucket(layer) as any);
        if (!bucket) {
            continue;
        }
        const buffers = isText ? bucket.textCollisionBox : bucket.iconCollisionBox;
        // Get collision circle data of this bucket
        const circleArray: number[] = bucket.collisionCircleArray;
        if (circleArray.length > 0) {
            tileBatches.push({
                circleArray,
                circleOffset,
                coord
            });

            circleCount += circleArray.length / 4;  // 4 values per circle
            circleOffset = circleCount;
        }

        // Draw collision boxes
        if (!buffers) {
            continue;
        }

        program.draw(context, gl.LINES,
            DepthMode.disabled, StencilMode.disabled,
            frameRenderContext.colorModeForRenderPass(),
            CullFaceMode.disabled,
            null,
            frameRenderContext.getTerrainDataForTile(coord),
            frameRenderContext.getProjectionDataForTile(coord),
            layer.id, buffers.layoutVertexBuffer, buffers.indexBuffer,
            buffers.segments, null, frameRenderContext.transform.zoom, null, null,
            buffers.collisionVertexBuffer);
    }

    if (!isText || !tileBatches.length) {
        return;
    }

    // Render collision circles
    const circleProgram = frameRenderContext.useProgram('collisionCircle');

    // Construct vertex data
    const vertexData = new CollisionCircleLayoutArray();
    vertexData.resize(circleCount * 4);
    vertexData._trim();

    let vertexOffset = 0;

    for (const batch of tileBatches) {
        for (let i = 0; i < batch.circleArray.length / 4; i++) {
            const circleIdx = i * 4;
            const x = batch.circleArray[circleIdx + 0];
            const y = batch.circleArray[circleIdx + 1];
            const radius = batch.circleArray[circleIdx + 2];
            const collision = batch.circleArray[circleIdx + 3];

            // 4 floats per vertex, 4 vertices per quad
            vertexData.emplace(vertexOffset++, x, y, radius, collision, 0);
            vertexData.emplace(vertexOffset++, x, y, radius, collision, 1);
            vertexData.emplace(vertexOffset++, x, y, radius, collision, 2);
            vertexData.emplace(vertexOffset++, x, y, radius, collision, 3);
        }
    }
    if (!quadTriangles || quadTriangles.length < circleCount * 2) {
        quadTriangles = createQuadTriangles(circleCount);
    }

    const indexBuffer: IndexBuffer = context.createIndexBuffer(quadTriangles, true);
    const vertexBuffer: VertexBuffer = context.createVertexBuffer(vertexData, collisionCircleLayout.members, true);

    // Render batches
    for (const batch of tileBatches) {

        circleProgram.draw(
            context,
            gl.TRIANGLES,
            DepthMode.disabled,
            StencilMode.disabled,
            frameRenderContext.colorModeForRenderPass(),
            CullFaceMode.disabled,
            null,
            frameRenderContext.getTerrainDataForTile(batch.coord),
            null,
            layer.id,
            vertexBuffer,
            indexBuffer,
            SegmentVector.simpleSegment(0, batch.circleOffset * 2, batch.circleArray.length, batch.circleArray.length / 2),
            null,
            frameRenderContext.transform.zoom,
            null,
            null,
            null);
    }

    vertexBuffer.destroy();
    indexBuffer.destroy();
}

function createQuadTriangles(quadCount: number): QuadTriangleArray {
    const triCount = quadCount * 2;
    const array = new QuadTriangleArray();

    array.resize(triCount);
    array._trim();

    // Two triangles and 4 vertices per quad.
    for (let i = 0; i < triCount; i++) {
        const idx = i * 6;

        array.uint16[idx + 0] = i * 4 + 0;
        array.uint16[idx + 1] = i * 4 + 1;
        array.uint16[idx + 2] = i * 4 + 2;
        array.uint16[idx + 3] = i * 4 + 2;
        array.uint16[idx + 4] = i * 4 + 3;
        array.uint16[idx + 5] = i * 4 + 0;
    }

    return array;
}
