import {Uniform1i, Uniform1f, Uniform2f} from '../uniform_binding.ts';
import {pixelsToTileUnits} from '../../source/pixels_to_tile_units.ts';
import {EXTENT} from '../../data/extent.ts';

import type {Context} from '../../webgl/context.ts';
import type {UniformValues, UniformLocations} from '../uniform_binding.ts';
import type {Tile} from '../../tile/tile.ts';
import type {CircleStyleLayer} from '../../style/style_layer/circle_style_layer.ts';
import type {IReadonlyTransform} from '../../geo/transform_interface.ts';

export type CircleUniformsType = {
    'u_scale_with_map': Uniform1i;
    'u_pitch_with_map': Uniform1i;
    'u_extrude_scale': Uniform2f;
    'u_globe_extrude_scale': Uniform1f;
    'u_translate': Uniform2f;
};

const circleUniforms = (context: Context, locations: UniformLocations): CircleUniformsType => ({
    'u_scale_with_map': new Uniform1i(context, locations.u_scale_with_map),
    'u_pitch_with_map': new Uniform1i(context, locations.u_pitch_with_map),
    'u_extrude_scale': new Uniform2f(context, locations.u_extrude_scale),
    'u_globe_extrude_scale': new Uniform1f(context, locations.u_globe_extrude_scale),
    'u_translate': new Uniform2f(context, locations.u_translate),
});

const circleUniformValues = (
    transform: IReadonlyTransform,
    tile: Tile,
    layer: CircleStyleLayer,
    translate: [number, number],
    radiusCorrectionFactor: number
): UniformValues<CircleUniformsType> => {
    let pitchWithMap: boolean, extrudeScale: [number, number];
    let globeExtrudeScale: number = 0;
    if (layer.paint.get('circle-pitch-alignment') === 'map') {
        const pixelRatio = pixelsToTileUnits(tile, 1, transform.zoom);
        pitchWithMap = true;
        extrudeScale = [pixelRatio, pixelRatio];

        // For globe rendering we need to know how much to extrude the circle as an *angle*.
        // The calculation: (one pixel in tile units) / (earth circumference in tile units) * (2PI radians) * radiusCorrectionFactor
        globeExtrudeScale = pixelRatio / (EXTENT * Math.pow(2, tile.tileID.overscaledZ)) * 2.0 * Math.PI * radiusCorrectionFactor;
    } else {
        pitchWithMap = false;
        extrudeScale = transform.pixelsToGLUnits;
    }

    return {
        'u_scale_with_map': +(layer.paint.get('circle-pitch-scale') === 'map'),
        'u_pitch_with_map': +(pitchWithMap),
        'u_extrude_scale': extrudeScale,
        'u_globe_extrude_scale': globeExtrudeScale,
        'u_translate': translate,
    };
};

export {circleUniforms, circleUniformValues};
