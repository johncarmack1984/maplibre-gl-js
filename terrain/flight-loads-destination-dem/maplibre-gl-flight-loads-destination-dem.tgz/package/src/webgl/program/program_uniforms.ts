import {fillExtrusionUniforms, fillExtrusionPatternUniforms, type FillExtrusionUniformsType, type FillExtrusionPatternUniformsType} from './fill_extrusion_program.ts';
import {fillPatternUniforms, fillOutlineUniforms, fillOutlinePatternUniforms, fillUniforms, type FillUniformsType, type FillPatternUniformsType, type FillOutlineUniformsType, type FillOutlinePatternUniformsType} from './fill_program.ts';
import {circleUniforms, type CircleUniformsType} from './circle_program.ts';
import {debugUniforms, type DebugUniformsType} from './debug_program.ts';
import {heatmapUniforms, heatmapTextureUniforms, type HeatmapUniformsType, type HeatmapTextureUniformsType} from './heatmap_program.ts';
import {hillshadeUniforms, hillshadePrepareUniforms, type HillshadeUniformsType, type HillshadePrepareUniformsType} from './hillshade_program.ts';
import {colorReliefUniforms, type ColorReliefUniformsType} from './color_relief_program.ts';
import {lineUniforms, lineGradientUniforms, linePatternUniforms, lineSDFUniforms, lineGradientSDFUniforms, type LineUniformsType, type LineGradientUniformsType, type LinePatternUniformsType, type LineSDFUniformsType, type LineGradientSDFUniformsType} from './line_program.ts';
import {layerOpacityUniforms, type LayerOpacityUniformsType} from './layer_opacity_program.ts';
import {rasterUniforms, type RasterUniformsType} from './raster_program.ts';
import {symbolIconUniforms, symbolSDFUniforms, symbolTextAndIconUniforms, type SymbolIconUniformsType, type SymbolSDFUniformsType, type symbolTextAndIconUniformsType} from './symbol_program.ts';
import {backgroundUniforms, backgroundPatternUniforms, type BackgroundUniformsType, type BackgroundPatternUniformsType} from './background_program.ts';
import {terrainUniforms, terrainDepthUniforms, terrainHeightUniforms, type TerrainUniformsType, type TerrainDepthUniformsType, type TerrainHeightUniformsType} from './terrain_program.ts';
import {atmosphereUniforms, type atmosphereUniformsType} from './atmosphere_program.ts';
import {skyUniforms, type SkyUniformsType} from './sky_program.ts';

import type {Context} from '../context.ts';
import type {UniformLocations} from '../uniform_binding.ts';

type EmptyUniforms = Record<string, never>;

const emptyUniforms = (_: Context, __: UniformLocations): EmptyUniforms => ({});

export const programUniforms: {
    fillExtrusion: (context: Context, locations: UniformLocations) => FillExtrusionUniformsType;
    fillExtrusionPattern: (context: Context, locations: UniformLocations) => FillExtrusionPatternUniformsType;
    fill: (context: Context, locations: UniformLocations) => FillUniformsType;
    fillPattern: (context: Context, locations: UniformLocations) => FillPatternUniformsType;
    fillOutline: (context: Context, locations: UniformLocations) => FillOutlineUniformsType;
    fillOutlinePattern: (context: Context, locations: UniformLocations) => FillOutlinePatternUniformsType;
    circle: (context: Context, locations: UniformLocations) => CircleUniformsType;
    collisionBox: (context: Context, locations: UniformLocations) => EmptyUniforms;
    collisionCircle: (context: Context, locations: UniformLocations) => EmptyUniforms;
    debug: (context: Context, locations: UniformLocations) => DebugUniformsType;
    depth: (context: Context, locations: UniformLocations) => EmptyUniforms;
    clippingMask: (context: Context, locations: UniformLocations) => EmptyUniforms;
    heatmap: (context: Context, locations: UniformLocations) => HeatmapUniformsType;
    heatmapTexture: (context: Context, locations: UniformLocations) => HeatmapTextureUniformsType;
    hillshade: (context: Context, locations: UniformLocations) => HillshadeUniformsType;
    hillshadePrepare: (context: Context, locations: UniformLocations) => HillshadePrepareUniformsType;
    colorRelief: (context: Context, locations: UniformLocations) => ColorReliefUniformsType;
    line: (context: Context, locations: UniformLocations) => LineUniformsType;
    lineGradient: (context: Context, locations: UniformLocations) => LineGradientUniformsType;
    linePattern: (context: Context, locations: UniformLocations) => LinePatternUniformsType;
    lineSDF: (context: Context, locations: UniformLocations) => LineSDFUniformsType;
    lineGradientSDF: (context: Context, locations: UniformLocations) => LineGradientSDFUniformsType;
    layerOpacity: (context: Context, locations: UniformLocations) => LayerOpacityUniformsType;
    raster: (context: Context, locations: UniformLocations) => RasterUniformsType;
    symbolIcon: (context: Context, locations: UniformLocations) => SymbolIconUniformsType;
    symbolSDF: (context: Context, locations: UniformLocations) => SymbolSDFUniformsType;
    symbolTextAndIcon: (context: Context, locations: UniformLocations) => symbolTextAndIconUniformsType;
    background: (context: Context, locations: UniformLocations) => BackgroundUniformsType;
    backgroundPattern: (context: Context, locations: UniformLocations) => BackgroundPatternUniformsType;
    terrain: (context: Context, locations: UniformLocations) => TerrainUniformsType;
    terrainDepth: (context: Context, locations: UniformLocations) => TerrainDepthUniformsType;
    terrainHeight: (context: Context, locations: UniformLocations) => TerrainHeightUniformsType;
    atmosphere: (context: Context, locations: UniformLocations) => atmosphereUniformsType;
    sky: (context: Context, locations: UniformLocations) => SkyUniformsType;
} = {
    fillExtrusion: fillExtrusionUniforms,
    fillExtrusionPattern: fillExtrusionPatternUniforms,
    fill: fillUniforms,
    fillPattern: fillPatternUniforms,
    fillOutline: fillOutlineUniforms,
    fillOutlinePattern: fillOutlinePatternUniforms,
    circle: circleUniforms,
    collisionBox: emptyUniforms,
    collisionCircle: emptyUniforms,
    debug: debugUniforms,
    depth: emptyUniforms,
    clippingMask: emptyUniforms,
    heatmap: heatmapUniforms,
    heatmapTexture: heatmapTextureUniforms,
    hillshade: hillshadeUniforms,
    hillshadePrepare: hillshadePrepareUniforms,
    colorRelief: colorReliefUniforms,
    line: lineUniforms,
    lineGradient: lineGradientUniforms,
    linePattern: linePatternUniforms,
    lineSDF: lineSDFUniforms,
    lineGradientSDF: lineGradientSDFUniforms,
    layerOpacity: layerOpacityUniforms,
    raster: rasterUniforms,
    symbolIcon: symbolIconUniforms,
    symbolSDF: symbolSDFUniforms,
    symbolTextAndIcon: symbolTextAndIconUniforms,
    background: backgroundUniforms,
    backgroundPattern: backgroundPatternUniforms,
    terrain: terrainUniforms,
    terrainDepth: terrainDepthUniforms,
    terrainHeight: terrainHeightUniforms,
    atmosphere: atmosphereUniforms,
    sky: skyUniforms
};
