import {clone, deepEqual, extend, easeCubicInOut, warnOnce} from '../util/util.ts';
import {interpolates, type Color, type StylePropertySpecification, normalizePropertyExpression,
    type Feature,
    type FeatureState,
    type StylePropertyExpression,
    type SourceExpression,
    type CompositeExpression, type TransitionSpecification,
    type PropertyValueSpecification} from '@maplibre/maplibre-gl-style-spec';
import {register} from '../util/web_worker_transfer.ts';
import {EvaluationParameters} from './evaluation_parameters.ts';

import type {CanonicalTileID} from '../tile/tile_id.ts';

type TimePoint = number;

export const TRANSITION_SUFFIX = '-transition';

/**
 * A from-to type
 */
export type CrossFaded<T> = {
    to: T;
    from: T;
};

/**
 * @internal
 *  Implementations of the `Property` interface:
 *
 *  * Hold metadata about a property that's independent of any specific value: stuff like the type of the value,
 *    the default value, etc. This comes from the style specification JSON.
 *  * Define behavior that needs to be polymorphic across different properties: "possibly evaluating"
 *    an input value (see below), and interpolating between two possibly-evaluted values.
 *
 *  The type `T` is the fully-evaluated value type (e.g. `number`, `string`, `Color`).
 *  The type `R` is the intermediate "possibly evaluated" value type. See below.
 *
 *  There are two main implementations of the interface -- one for properties that allow data-driven values,
 *  and one for properties that don't. There are a few "special case" implementations as well: one for properties
 *  which cross-fade between two values rather than interpolating, one for `heatmap-color` and `line-gradient`,
 *  and one for `light-position`.
 */
export interface Property<T, R> {
    specification: StylePropertySpecification;
    name: string;
    possiblyEvaluate(
        value: PropertyValue<T, R>,
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): R;
    interpolate(a: R, b: R, t: number): R;
}

/**
 * @internal
 *  `PropertyValue` represents the value part of a property key-value unit. It's used to represent both
 *  paint and layout property values, and regardless of whether or not their property supports data-driven
 *  expressions.
 *
 *  `PropertyValue` stores the raw input value as seen in a style or a runtime styling API call, i.e. one of the
 *  following:
 *
 *    * A constant value of the type appropriate for the property
 *    * A function which produces a value of that type (but functions are quasi-deprecated in favor of expressions)
 *    * An expression which produces a value of that type
 *    * "undefined"/"not present", in which case the property is assumed to take on its default value.
 *
 *  In addition to storing the original input value, `PropertyValue` also stores a normalized representation,
 *  effectively treating functions as if they are expressions, and constant or default values as if they are
 *  (constant) expressions.
 */
export class PropertyValue<T, R> {
    property: Property<T, R>;
    value: PropertyValueSpecification<T> | void;
    expression: StylePropertyExpression;

    constructor(property: Property<T, R>, value: PropertyValueSpecification<T> | void, rootKey: string, globalState: Record<string, any>) {
        this.property = property;
        this.value = value;
        this.expression = normalizePropertyExpression(value === undefined ? property.specification.default : value, rootKey, property.specification, globalState);
    }

    isDataDriven(): boolean {
        return this.expression.kind === 'source' || this.expression.kind === 'composite';
    }

    getGlobalStateRefs(): Set<string> {
        return this.expression.globalStateRefs || new Set<string>();
    }

    /** Whether the expression reads one of the global state keys in `refs`. */
    readsGlobalState(refs: string[]): boolean {
        const globalStateRefs = this.getGlobalStateRefs();
        return refs.some(ref => globalStateRefs.has(ref));
    }

    possiblyEvaluate(
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): R {
        return this.property.possiblyEvaluate(this, parameters, canonical, availableImages);
    }
}

export type TransitionParameters = {
    now: TimePoint;
    transition: TransitionSpecification;
};

/**
 * @internal
 * Paint properties are _transitionable_: they can change in a fluid manner, interpolating or cross-fading between
 * old and new value. The duration of the transition, and the delay before it begins, is configurable.
 *
 * `TransitionablePropertyValue` is a compositional class that stores both the property value and that transition
 * configuration.
 *
 * A `TransitionablePropertyValue` can calculate the next step in the evaluation chain for paint property values:
 * `TransitioningPropertyValue`.
 */
class TransitionablePropertyValue<T, R> {
    property: Property<T, R>;
    value: PropertyValue<T, R>;
    transition: TransitionSpecification | void;

    constructor(property: Property<T, R>, rootKey: string, globalState: Record<string, any>) {
        this.property = property;
        this.value = new PropertyValue(property, undefined, rootKey, globalState);
    }

    /** The same `PropertyValue` means `setValue` was never called, so there is nothing to transition to. */
    transitioned(parameters: TransitionParameters, prior: TransitioningPropertyValue<T, R>): TransitioningPropertyValue<T, R> {
        if (prior.value === this.value) return prior;
        return new TransitioningPropertyValue(this.property, this.value, prior,
            extend({}, parameters.transition, this.transition), parameters.now);
    }

    untransitioned(): TransitioningPropertyValue<T, R> {
        return new TransitioningPropertyValue(this.property, this.value, null, {}, 0);
    }
}

/**
 * @internal
 * `Transitionable` stores a map of all (property name, `TransitionablePropertyValue`) pairs for paint properties of a
 * given layer type. It can calculate the `TransitioningPropertyValue`s for all of them at once, producing a
 * `Transitioning` instance for the same set of properties.
 */
export class Transitionable<Props> {
    _properties: Properties<Props>;
    _values: {[K in keyof Props]: TransitionablePropertyValue<any, unknown>};
    private _globalState: Record<string, any>;
    private _rootKey: string;

    constructor(properties: Properties<Props>, rootKey: string, globalState: Record<string, any>) {
        this._properties = properties;
        this._values = (Object.create(properties.defaultTransitionablePropertyValues));
        this._globalState = globalState;
        this._rootKey = rootKey;
    }

    /** rootKey of a property, e.g. `layers[3].paint.line-color`. */
    private _propertyRootKey(name: keyof Props): string {
        return `${this._rootKey}.${String(name)}`;
    }

    hasProperty(name: string): boolean {
        return name in this._properties.defaultTransitionablePropertyValues;
    }

    getValue<S extends keyof Props, T>(name: S): PropertyValueSpecification<T> | void {
        return clone(this._values[name].value.value);
    }

    setValue<S extends keyof Props, T>(name: S, value: PropertyValueSpecification<T> | void): void {
        if (!Object.hasOwn(this._values, name)) {
            this._values[name] = new TransitionablePropertyValue(this._values[name].property, this._propertyRootKey(name), this._globalState);
        }
        // Note that we do not _remove_ an own property in the case where a value is being reset
        // to the default: the transition might still be non-default.
        this._values[name].value = new PropertyValue(this._values[name].property, value === null ? undefined : clone(value), this._propertyRootKey(name), this._globalState);
    }

    /** Applies a whole spec, skipping the values we already hold so they do not transition. */
    setValues(values: {[name: string]: unknown}): void {
        for (const name in values) {
            const value = values[name];
            if (name.endsWith(TRANSITION_SUFFIX)) {
                this.setTransition(name.slice(0, -TRANSITION_SUFFIX.length) as keyof Props, value);
            } else if (!deepEqual(this._values[name].value.value, value)) {
                this.setValue(name as keyof Props, value);
            }
        }
    }

    getTransition<S extends keyof Props>(name: S): TransitionSpecification | void {
        return clone(this._values[name].transition);
    }

    setTransition<S extends keyof Props>(name: S, value: TransitionSpecification | void): void {
        if (!Object.hasOwn(this._values, name)) {
            this._values[name] = new TransitionablePropertyValue(this._values[name].property, this._propertyRootKey(name), this._globalState);
        }
        this._values[name].transition = clone(value) || undefined;
    }

    /** Keeps the transitions running in `transitioning` on `priorGlobalState` where they read one of `refs` live. */
    retainPriorGlobalState(refs: string[], priorGlobalState: Record<string, any>, transitioning: Transitioning<Props>): void {
        for (const name of Object.keys(transitioning._values)) {
            for (let step: TransitioningPropertyValue<any, unknown> = transitioning._values[name]; step; step = step.prior) {
                const {value} = step;
                if (!value.property.specification.transition || value.isDataDriven() ||
                    value.expression._globalState !== this._globalState || !value.readsGlobalState(refs)) continue;

                step.value = new PropertyValue(value.property, value.value, this._propertyRootKey(name as keyof Props), priorGlobalState);
            }
        }
    }

    /** Reads every value that reads one of `refs` again and transitions it from what `transitioning` shows. */
    applyGlobalStateChange(refs: string[], priorGlobalState: Record<string, any>, transitioning: Transitioning<Props>, parameters: TransitionParameters): Transitioning<Props> {
        this.retainPriorGlobalState(refs, priorGlobalState, transitioning);
        let changed = false;
        for (const name of Object.keys(this._values)) {
            const {value} = this._values[name];
            if (!value.readsGlobalState(refs)) continue;

            this.setValue(name as keyof Props, value.value);
            changed = true;
        }
        return changed ? this.transitioned(parameters, transitioning) : transitioning;
    }

    serialize(): any {
        const result: any = {};
        for (const property of Object.keys(this._values)) {
            const value = this.getValue(property as keyof Props);
            if (value !== undefined) {
                result[property] = value;
            }

            const transition = this.getTransition(property as keyof Props);
            if (transition !== undefined) {
                result[`${property}${TRANSITION_SUFFIX}`] = transition;
            }
        }
        return result;
    }

    transitioned(parameters: TransitionParameters, prior: Transitioning<Props>): Transitioning<Props> {
        const result = new Transitioning(this._properties);
        for (const property of Object.keys(this._values)) {
            result._values[property] = this._values[property].transitioned(parameters, prior._values[property]);
        }
        return result;
    }

    untransitioned(): Transitioning<Props> {
        const result = new Transitioning(this._properties);
        for (const property of Object.keys(this._values)) {
            result._values[property] = this._values[property].untransitioned();
        }
        return result;
    }
}

/**
 * @internal
 * `TransitioningPropertyValue` implements the first of two intermediate steps in the evaluation chain of a paint
 * property value. In this step, transitions between old and new values are handled: as long as the transition is in
 * progress, `TransitioningPropertyValue` maintains a reference to the prior value, and interpolates between it and
 * the new value based on the current time and the configured transition duration and delay. The product is the next
 * step in the evaluation chain: the "possibly evaluated" result type `R`. See below for more on this concept.
 */
class TransitioningPropertyValue<T, R> {
    property: Property<T, R>;
    value: PropertyValue<T, R>;
    prior: TransitioningPropertyValue<T, R>;
    begin: TimePoint;
    end: TimePoint;

    constructor(property: Property<T, R>,
        value: PropertyValue<T, R>,
        prior: TransitioningPropertyValue<T, R>,
        transition: TransitionSpecification,
        now: TimePoint) {
        this.property = property;
        this.value = value;
        this.begin = now + transition.delay || 0;
        this.end = this.begin + transition.duration || 0;
        if (property.specification.transition && (transition.delay || transition.duration)) {
            this.prior = prior;
        }
    }

    possiblyEvaluate(
        parameters: EvaluationParameters,
        canonical: CanonicalTileID,
        availableImages: string[]
    ): R {
        const now = parameters.now || 0;
        const finalValue = this.value.possiblyEvaluate(parameters, canonical, availableImages);
        const prior = this.prior;
        if (!prior) {
            // No prior value.
            return finalValue;
        } else if (now > this.end) {
            // Transition from prior value is now complete.
            this.prior = null;
            return finalValue;
        } else if (this.value.isDataDriven()) {
            // Transitions to data-driven properties are not supported.
            // We snap immediately to the data-driven value so that, when we perform layout,
            // we see the data-driven function and can use it to populate vertex buffers.
            this.prior = null;
            return finalValue;
        } else if (now < this.begin) {
            // Transition hasn't started yet.
            return prior.possiblyEvaluate(parameters, canonical, availableImages);
        } else {
            // Interpolate between recursively-calculated prior value and final.
            const t = (now - this.begin) / (this.end - this.begin);
            return this.property.interpolate(prior.possiblyEvaluate(parameters, canonical, availableImages), finalValue, easeCubicInOut(t));
        }
    }
}

/**
 * @internal
 * `Transitioning` stores a map of all (property name, `TransitioningPropertyValue`) pairs for paint properties of a
 * given layer type. It can calculate the possibly-evaluated values for all of them at once, producing a
 * `PossiblyEvaluated` instance for the same set of properties.
 */
export class Transitioning<Props> {
    _properties: Properties<Props>;
    _values: {[K in keyof Props]: PossiblyEvaluatedPropertyValue<unknown>};

    constructor(properties: Properties<Props>) {
        this._properties = properties;
        this._values = (Object.create(properties.defaultTransitioningPropertyValues));
    }

    possiblyEvaluate(
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): PossiblyEvaluated<Props, any> {
        const result = new PossiblyEvaluated(this._properties);
        for (const property of Object.keys(this._values)) {
            result._values[property] = this._values[property].possiblyEvaluate(parameters, canonical, availableImages);
        }
        return result;
    }

    hasTransition(): boolean {
        for (const property of Object.keys(this._values)) {
            if (this._values[property].prior) {
                return true;
            }
        }
        return false;
    }
}

// ------- Layout -------

/**
 * Because layout properties are not transitionable, they have a simpler representation and evaluation chain than
 * paint properties: `PropertyValue`s are possibly evaluated, producing possibly evaluated values, which are then
 * fully evaluated.
 *
 * `Layout` stores a map of all (property name, `PropertyValue`) pairs for layout properties of a
 * given layer type. It can calculate the possibly-evaluated values for all of them at once, producing a
 * `PossiblyEvaluated` instance for the same set of properties.
 */
export class Layout<Props> {
    _properties: Properties<Props>;
    _values: {[K in keyof Props]: PropertyValue<any, PossiblyEvaluatedPropertyValue<any>>};
    private _globalState: Record<string, any>; // reference to global state
    private _rootKey: string;

    constructor(properties: Properties<Props>, rootKey: string, globalState: Record<string, any>) {
        this._properties = properties;
        this._values = (Object.create(properties.defaultPropertyValues));
        this._globalState = globalState;
        this._rootKey = rootKey;
    }

    /** rootKey of a property, e.g. `layers[3].layout.line-cap`. */
    private _propertyRootKey(name: keyof Props): string {
        return `${this._rootKey}.${String(name)}`;
    }

    hasValue<S extends keyof Props>(name: S): boolean {
        return this._values[name].value !== undefined;
    }

    hasProperty(name: string): boolean {
        return name in this._properties.defaultPropertyValues;
    }

    getValue<S extends keyof Props>(name: S): any {
        return clone(this._values[name].value);
    }

    setValue<S extends keyof Props>(name: S, value: any): void {
        this._values[name] = new PropertyValue(this._values[name].property, value === null ? undefined : clone(value), this._propertyRootKey(name), this._globalState) as any;
    }

    serialize(): any {
        const result: any = {};
        for (const property of Object.keys(this._values)) {
            const value = this.getValue(property as keyof Props);
            if (value !== undefined) {
                result[property] = value;
            }
        }
        return result;
    }

    possiblyEvaluate(
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): PossiblyEvaluated<Props, any> {
        const result = new PossiblyEvaluated(this._properties);
        for (const property of Object.keys(this._values)) {
            result._values[property] = this._values[property].possiblyEvaluate(parameters, canonical, availableImages);
        }
        return result;
    }
}

// ------- PossiblyEvaluated -------

/**
 * "Possibly evaluated value" is an intermediate stage in the evaluation chain for both paint and layout property
 * values. The purpose of this stage is to optimize away unnecessary recalculations for data-driven properties. Code
 * which uses data-driven property values must assume that the value is dependent on feature data, and request that it
 * be evaluated for each feature. But when that property value is in fact a constant or camera function, the calculation
 * will not actually depend on the feature, and we can benefit from returning the prior result of having done the
 * evaluation once, ahead of time, in an intermediate step whose inputs are just the value and "global" parameters
 * such as current zoom level.
 *
 * `PossiblyEvaluatedValue` represents the three possible outcomes of this step: if the input value was a constant or
 * camera expression, then the "possibly evaluated" result is a constant value. Otherwise, the input value was either
 * a source or composite expression, and we must defer final evaluation until supplied a feature. We separate
 * the source and composite cases because they are handled differently when generating GL attributes, buffers, and
 * uniforms.
 *
 * Note that `PossiblyEvaluatedValue` (and `PossiblyEvaluatedPropertyValue`, below) are _not_ used for properties that
 * do not allow data-driven values. For such properties, we know that the "possibly evaluated" result is always a constant
 * scalar value. See below.
 */
type PossiblyEvaluatedValue<T> = {
    kind: 'constant';
    value: T;
} | SourceExpression | CompositeExpression;

/**
 * @internal
 * `PossiblyEvaluatedPropertyValue` is used for data-driven paint and layout property values. It holds a
 * `PossiblyEvaluatedValue` and the `GlobalProperties` that were used to generate it. You're not allowed to supply
 * a different set of `GlobalProperties` when performing the final evaluation because they would be ignored in the
 * case where the input value was a constant or camera function.
 */
export class PossiblyEvaluatedPropertyValue<T> {
    property: DataDrivenProperty<T>;
    value: PossiblyEvaluatedValue<T>;
    parameters: EvaluationParameters;

    constructor(property: DataDrivenProperty<T>, value: PossiblyEvaluatedValue<T>, parameters: EvaluationParameters) {
        this.property = property;
        this.value = value;
        this.parameters = parameters;
    }

    isConstant(): boolean {
        return this.value.kind === 'constant';
    }

    constantOr(value: T): T {
        if (this.value.kind === 'constant') {
            return this.value.value;
        } else {
            return value;
        }
    }

    evaluate(
        feature: Feature,
        featureState: FeatureState,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): T {
        return this.property.evaluate(this.value, this.parameters, feature, featureState, canonical, availableImages);
    }
}

/**
 * @internal
 * `PossiblyEvaluated` stores a map of all (property name, `R`) pairs for paint or layout properties of a
 * given layer type.
 */
export class PossiblyEvaluated<Props, PossibleEvaluatedProps> {
    _properties: Properties<Props>;
    _values: PossibleEvaluatedProps;

    constructor(properties: Properties<Props>) {
        this._properties = properties;
        this._values = Object.create(properties.defaultPossiblyEvaluatedValues);
    }

    get<S extends keyof PossibleEvaluatedProps>(name: S): PossibleEvaluatedProps[S] {
        return this._values[name];
    }
}

/**
 * Returns the length of the array value, or undefined if the value is not an array or a style spec array wrapper.
 */
function getArrayValueLength(value: unknown): number | undefined {
    if (Array.isArray(value)) {
        return value.length;
    }
    const values = (value as {values?: unknown})?.values;
    return Array.isArray(values) ? values.length : undefined;
}

/**
 * Returns true if the two values are arrays of different length, either bare arrays or style spec array wrappers.
 */
function isNonInterpolableArrayChange(a: unknown, b: unknown): boolean {
    const lengthA = getArrayValueLength(a);
    const lengthB = getArrayValueLength(b);
    return lengthA !== undefined && lengthB !== undefined && lengthA !== lengthB;
}

/**
 * @internal
 * An implementation of `Property` for properties that do not permit data-driven (source or composite) expressions.
 * This restriction allows us to declare statically that the result of possibly evaluating this kind of property
 * is in fact always the scalar type `T`, and can be used without further evaluating the value on a per-feature basis.
 */
export class DataConstantProperty<T> implements Property<T, T> {
    specification: StylePropertySpecification;
    name: string;

    constructor(specification: StylePropertySpecification, name: string) {
        this.specification = specification;
        this.name = name;
    }

    possiblyEvaluate(value: PropertyValue<T, T>, parameters: EvaluationParameters): T {
        if (value.isDataDriven()) throw new Error('Value should not be data driven');
        return value.expression.evaluate(parameters);
    }

    interpolate(a: T, b: T, t: number): T {
        if (isNonInterpolableArrayChange(a, b)) {
            warnOnce(`Property "${this.name}" is trying to interpolate arrays of different lengths. Rendering may 'jump'.`);
            return b;
        }
        const interpolationType = this.specification.type as keyof typeof interpolates;
        const interpolationFn = interpolates[interpolationType] as ((from: T, to: T, t: number) => T) | undefined;
        if (interpolationFn) {
            return interpolationFn(a, b, t);
        } else {
            return a;
        }
    }
}

/**
 * @internal
 * An implementation of `Property` for properties that permit data-driven (source or composite) expressions.
 * The result of possibly evaluating this kind of property is `PossiblyEvaluatedPropertyValue<T>`; obtaining
 * a scalar value `T` requires further evaluation on a per-feature basis.
 */
export class DataDrivenProperty<T> implements Property<T, PossiblyEvaluatedPropertyValue<T>> {
    specification: StylePropertySpecification;
    name: string;
    overrides: any;

    constructor(specification: StylePropertySpecification, name: string, overrides?: any) {
        this.specification = specification;
        this.name = name;
        this.overrides = overrides;
    }

    possiblyEvaluate(
        value: PropertyValue<T, PossiblyEvaluatedPropertyValue<T>>,
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): PossiblyEvaluatedPropertyValue<T> {
        if (value.expression.kind === 'constant' || value.expression.kind === 'camera') {
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: value.expression.evaluate(parameters, null, {}, canonical, availableImages)}, parameters);
        } else {
            return new PossiblyEvaluatedPropertyValue(this, value.expression, parameters);
        }
    }

    interpolate(
        a: PossiblyEvaluatedPropertyValue<T>,
        b: PossiblyEvaluatedPropertyValue<T>,
        t: number
    ): PossiblyEvaluatedPropertyValue<T> {
        // If either possibly-evaluated value is non-constant, give up: we aren't able to interpolate data-driven values.
        if (a.value.kind !== 'constant' || b.value.kind !== 'constant') {
            return a;
        }

        // Special case hack solely for fill-outline-color. The undefined value is subsequently handled in
        // FillStyleLayer.recalculate, which sets fill-outline-color to the fill-color value if the former
        // is a PossiblyEvaluatedPropertyValue containing a constant undefined value. In addition to the
        // return value here, the other source of a PossiblyEvaluatedPropertyValue containing a constant
        // undefined value is the "default value" for fill-outline-color held in
        // `Properties.defaultPossiblyEvaluatedValues`, which serves as the prototype of
        // `PossiblyEvaluated._values`.
        if (a.value.value === undefined || b.value.value === undefined) {
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: undefined}, a.parameters);
        }

        if (isNonInterpolableArrayChange(a.value.value, b.value.value)) {
            warnOnce(`Property "${this.name}" is trying to interpolate arrays of different lengths. Rendering may 'jump'.`);
            return b;
        }

        const interpolationType = this.specification.type as keyof typeof interpolates;
        const interpolationFn = interpolates[interpolationType] as ((from: T, to: T, t: number) => T) | undefined;
        if (interpolationFn) {
            const interpolatedValue = interpolationFn(a.value.value, b.value.value, t);
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: interpolatedValue}, a.parameters);
        } else {
            return a;
        }
    }

    evaluate(
        value: PossiblyEvaluatedValue<T>,
        parameters: EvaluationParameters,
        feature: Feature,
        featureState: FeatureState,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): T {
        if (value.kind === 'constant') {
            return value.value;
        } else {
            return value.evaluate(parameters, feature, featureState, canonical, availableImages);
        }
    }
}

/**
 * @internal
 * An implementation of `Property` for  data driven `line-pattern` which are transitioned by cross-fading
 * rather than interpolation.
 */

export class CrossFadedDataDrivenProperty<T> extends DataDrivenProperty<CrossFaded<T>> {

    possiblyEvaluate(
        value: PropertyValue<CrossFaded<T>, PossiblyEvaluatedPropertyValue<CrossFaded<T>>>,
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): PossiblyEvaluatedPropertyValue<CrossFaded<T>> {
        if (value.value === undefined) {
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: undefined}, parameters);
        } else if (value.expression.kind === 'constant') {
            const evaluatedValue = value.expression.evaluate(parameters, null, {}, canonical, availableImages);
            const isImageExpression = value.property.specification.type as any === 'resolvedImage';
            const constantValue = isImageExpression && typeof evaluatedValue !== 'string' ? evaluatedValue.name : evaluatedValue;
            const constant = this._calculate(constantValue, constantValue, constantValue, parameters);
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: constant}, parameters);
        } else if (value.expression.kind === 'camera') {
            const cameraVal = this._calculate(
                value.expression.evaluate({zoom: parameters.zoom - 1.0}),
                value.expression.evaluate({zoom: parameters.zoom}),
                value.expression.evaluate({zoom: parameters.zoom + 1.0}),
                parameters);
            return new PossiblyEvaluatedPropertyValue(this, {kind: 'constant', value: cameraVal}, parameters);
        } else {
            // source or composite expression
            return new PossiblyEvaluatedPropertyValue(this, value.expression, parameters);
        }
    }

    evaluate(
        value: PossiblyEvaluatedValue<CrossFaded<T>>,
        globals: EvaluationParameters,
        feature: Feature,
        featureState: FeatureState,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): CrossFaded<T> {
        if (value.kind === 'source') {
            const constant = value.evaluate(globals, feature, featureState, canonical, availableImages);
            return this._calculate(constant, constant, constant, globals);
        } else if (value.kind === 'composite') {
            return this._calculate(
                value.evaluate({zoom: Math.floor(globals.zoom) - 1.0}, feature, featureState),
                value.evaluate({zoom: Math.floor(globals.zoom)}, feature, featureState),
                value.evaluate({zoom: Math.floor(globals.zoom) + 1.0}, feature, featureState),
                globals);
        } else {
            return value.value;
        }
    }

    _calculate(min: T, mid: T, max: T, parameters: EvaluationParameters): CrossFaded<T> {
        const z = parameters.zoom;
        return z > parameters.zoomHistory.lastIntegerZoom ? {from: min, to: mid} : {from: max, to: mid};
    }

    interpolate(a: PossiblyEvaluatedPropertyValue<CrossFaded<T>>): PossiblyEvaluatedPropertyValue<CrossFaded<T>> {
        return a;
    }
}
/**
 * @internal
 * An implementation of `Property` for `*-pattern` and `line-dasharray`, which are transitioned by cross-fading
 * rather than interpolation.
 */
export class CrossFadedProperty<T> implements Property<T, CrossFaded<T>> {
    specification: StylePropertySpecification;
    name: string;

    constructor(specification: StylePropertySpecification, name: string) {
        this.specification = specification;
        this.name = name;
    }

    possiblyEvaluate(
        value: PropertyValue<T, CrossFaded<T>>,
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): CrossFaded<T> {
        if (value.value === undefined) {
            return undefined;
        } else if (value.expression.kind === 'constant') {
            const constant = value.expression.evaluate(parameters, null, {}, canonical, availableImages);
            return this._calculate(constant, constant, constant, parameters);
        } else {
            return this._calculate(
                value.expression.evaluate(new EvaluationParameters(Math.floor(parameters.zoom - 1.0), parameters)),
                value.expression.evaluate(new EvaluationParameters(Math.floor(parameters.zoom), parameters)),
                value.expression.evaluate(new EvaluationParameters(Math.floor(parameters.zoom + 1.0), parameters)),
                parameters);
        }
    }

    _calculate(min: T, mid: T, max: T, parameters: EvaluationParameters): CrossFaded<T> {
        const z = parameters.zoom;
        return z > parameters.zoomHistory.lastIntegerZoom ? {from: min, to: mid} : {from: max, to: mid};
    }

    interpolate(a?: CrossFaded<T> | null): CrossFaded<T> {
        return a;
    }
}

/**
 * @internal
 * An implementation of `Property` for `heatmap-color` and `line-gradient`. Interpolation is a no-op, and
 * evaluation returns a boolean value in order to indicate its presence, but the real
 * evaluation happens in StyleLayer classes.
 */

export class ColorRampProperty implements Property<Color, boolean> {
    specification: StylePropertySpecification;
    name: string;

    constructor(specification: StylePropertySpecification, name: string) {
        this.specification = specification;
        this.name = name;
    }

    possiblyEvaluate(
        value: PropertyValue<Color, boolean>,
        parameters: EvaluationParameters,
        canonical?: CanonicalTileID,
        availableImages?: string[]
    ): boolean {
        return !!value.expression.evaluate(parameters, null, {}, canonical, availableImages);
    }

    interpolate(): boolean { return false; }
}

/**
 * @internal
 * `Properties` holds objects containing default values for the layout or paint property set of a given
 * layer type. These objects are immutable, and they are used as the prototypes for the `_values` members of
 * `Transitionable`, `Transitioning`, `Layout`, and `PossiblyEvaluated`. This allows these classes to avoid
 * doing work in the common case where a property has no explicit value set and should be considered to take
 * on the default value: using `for (const property of Object.keys(this._values))`, they can iterate over
 * only the _own_ properties of `_values`, skipping repeated calculation of transitions and possible/final
 * evaluations for defaults, the result of which will always be the same.
 */
export class Properties<Props> {
    properties: Props;
    defaultPropertyValues: {[K in keyof Props]: PropertyValue<unknown, any>};
    defaultTransitionablePropertyValues: {[K in keyof Props]: TransitionablePropertyValue<unknown, unknown>};
    defaultTransitioningPropertyValues: {[K in keyof Props]: TransitioningPropertyValue<unknown, unknown>};
    defaultPossiblyEvaluatedValues: {[K in keyof Props]: PossiblyEvaluatedPropertyValue<unknown>};
    overridableProperties: string[];

    constructor(properties: Props) {
        this.properties = properties;
        this.defaultPropertyValues = ({} as any);
        this.defaultTransitionablePropertyValues = ({} as any);
        this.defaultTransitioningPropertyValues = ({} as any);
        this.defaultPossiblyEvaluatedValues = ({} as any);
        this.overridableProperties = ([]);

        for (const property in properties) {
            const prop = properties[property] as any;
            if (prop.specification.overridable) {
                this.overridableProperties.push(property);
            }
            // These defaults are shared across all layers, so we only have the property name as a location
            // here. The full location (e.g. `layers[3].paint.line-color`) is filled in later when an actual
            // value is set through Transitionable/Layout.
            const defaultPropertyValue = this.defaultPropertyValues[property] =
                new PropertyValue(prop, undefined, prop.name, undefined);
            const defaultTransitionablePropertyValue = this.defaultTransitionablePropertyValues[property] =
                new TransitionablePropertyValue(prop, prop.name, undefined);
            this.defaultTransitioningPropertyValues[property] =
                defaultTransitionablePropertyValue.untransitioned();
            this.defaultPossiblyEvaluatedValues[property] =
                defaultPropertyValue.possiblyEvaluate({} as any);
        }
    }
}

register('DataDrivenProperty', DataDrivenProperty);
register('DataConstantProperty', DataConstantProperty);
register('CrossFadedDataDrivenProperty', CrossFadedDataDrivenProperty);
register('CrossFadedProperty', CrossFadedProperty);
register('ColorRampProperty', ColorRampProperty);
