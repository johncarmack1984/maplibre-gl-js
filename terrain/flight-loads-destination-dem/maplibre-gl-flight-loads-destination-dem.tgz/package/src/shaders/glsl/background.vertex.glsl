layout(location = 0) in vec2 a_pos;

void main() {
    gl_Position = projectTile(a_pos, a_pos);
}
