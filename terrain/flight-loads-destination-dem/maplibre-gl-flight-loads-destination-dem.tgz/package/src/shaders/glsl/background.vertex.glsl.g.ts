// This file is generated. Edit build/generate-shaders.ts, then run `npm run codegen`.
export default 'layout(location=0) in vec2 a_pos;void main() {gl_Position=projectTile(a_pos,a_pos);}';
