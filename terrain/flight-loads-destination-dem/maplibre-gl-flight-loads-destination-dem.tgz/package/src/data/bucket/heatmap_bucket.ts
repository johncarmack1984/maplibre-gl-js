import {CircleBucket} from './circle_bucket.ts';
import {register} from '../../util/web_worker_transfer.ts';

import type {HeatmapStyleLayer} from '../../style/style_layer/heatmap_style_layer.ts';

export class HeatmapBucket extends CircleBucket<HeatmapStyleLayer> {
    // Needed for flow to accept omit: ['layers'] below, due to
    // https://github.com/facebook/flow/issues/4262
    layers: HeatmapStyleLayer[];
}

register('HeatmapBucket', HeatmapBucket, {omit: ['layers']});
