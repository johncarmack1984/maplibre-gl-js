import {describe, beforeEach, test, expect, vi, afterEach} from 'vitest';
import * as timeControl from '../../util/time_control.ts';
import {Map} from '../map.ts';
import {DOM} from '../../util/dom.ts';
import simulate from '../../../test/unit/lib/simulate_interaction.ts';
import {beforeMapTest} from '../../util/test/util.ts';

function createMap() {
    return new Map({style: '', container: DOM.create('div', '', window.document.body)});
}

describe('Map.isZooming', () => {
    let map: Map;
    beforeEach(() => {
        beforeMapTest();
        map = createMap();
    });
    afterEach(() => {
        map.remove();
    });

    test('returns false by default', () => {
        expect(map.isZooming()).toBe(false);
    });

    test('returns true during a camera zoom animation', async () => {
        map.on('zoomstart', () => {
            expect(map.isZooming()).toBe(true);
        });

        const zoomEndPromise = map.once('zoomend');

        map.zoomTo(5, {duration: 0});
        await zoomEndPromise;
        expect(map.isZooming()).toBe(false);
    });

    test('returns true when scroll zooming', async () => {
        map.on('zoomstart', () => {
            expect(map.isZooming()).toBe(true);
        });

        const zoomEndPromise = map.once('zoomend');

        let now = 0;
        vi.spyOn(timeControl, 'now').mockImplementation(() => now);

        simulate.wheel(map.getCanvas(), {deltaY: -simulate.magicWheelZoomDelta});
        map._renderTaskQueue.run();

        now += 400;
        setTimeout(() => {
            map._renderTaskQueue.run();
        }, 400);

        await zoomEndPromise;
        expect(map.isZooming()).toBe(false);
    });

    test('returns true when double-click zooming', async () => {
        map.on('zoomstart', () => {
            expect(map.isZooming()).toBe(true);
        });

        const zoomEndPromise = map.once('zoomend');

        let now = 0;
        vi.spyOn(timeControl, 'now').mockImplementation(() => now);

        simulate.dblclick(map.getCanvas());
        map._renderTaskQueue.run();

        now += 500;
        map._renderTaskQueue.run();

        await zoomEndPromise;
        expect(map.isZooming()).toBe(false);
    });
});
