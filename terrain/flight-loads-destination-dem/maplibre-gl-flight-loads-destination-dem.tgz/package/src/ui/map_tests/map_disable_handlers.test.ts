import {beforeEach, test, expect} from 'vitest';
import {createMap, beforeMapTest} from '../../util/test/util.ts';

beforeEach(() => {
    beforeMapTest();
    global.fetch = null;
});

test('disable all handlers', () => {
    const map = createMap({interactive: false});

    expect(map.boxZoom.isEnabled()).toBeFalsy();
    expect(map.doubleClickZoom.isEnabled()).toBeFalsy();
    expect(map.dragPan.isEnabled()).toBeFalsy();
    expect(map.dragRotate.isEnabled()).toBeFalsy();
    expect(map.keyboard.isEnabled()).toBeFalsy();
    expect(map.scrollZoom.isEnabled()).toBeFalsy();
    expect(map.touchZoomRotate.isEnabled()).toBeFalsy();
});

const handlerNames = [
    'scrollZoom',
    'boxZoom',
    'dragRotate',
    'dragPan',
    'keyboard',
    'doubleClickZoom',
    'touchZoomRotate'
];
test.each(handlerNames)('disable "%s" handler', (handlerName) => {
    const options = {};
    options[handlerName] = false;
    const map = createMap(options);

    expect(map[handlerName].isEnabled()).toBeFalsy();
});
